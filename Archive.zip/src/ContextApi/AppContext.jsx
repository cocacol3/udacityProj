import { createContext, useEffect, useState } from 'react';
import { update, getAll } from "../BooksAPI";
import React from 'react';

export const AppContext = createContext();

const AppProvider = ({ children }) => {
    const [bookStateAppContext, setBookStateAppContext] = useState([]);
    // const [refetchBook, setRefetchBook] = useState(false);
    // console.log('refetchBook: ', refetchBook);
    // console.log('bookList', bookList)

    // const currentlyReadingList = bookList.filter(
    //     (books) => books.shelf === "currentlyReading"
    // );
    // const wantToReadList = bookList.filter(
    //     (books) => books.shelf === "wantToRead"
    // );
    // const readList = bookList.filter((books) => books.shelf === "read");

    // useEffect(() => {
    //     const fetchBooks = async () => {
    //         const response = await getAll();
    //         setBookList(response);
    //     };
    //     fetchBooks();
    // }, [refetchBook]);

    const onChangeBookShelf = async (bookID, shelf) => {
        const response = await update(bookID, shelf);
        console.log("response", response);
    };

    // const updateBookList = (e, id) => {
    //     let newArr = [...bookList];

    //     const bookIndex = newArr.findIndex((book) => book?.id === id);

    //     if (bookIndex !== -1) {
    //         newArr[bookIndex].shelf = e?.target?.value;
    //         setBookList(newArr);
    //     }

    //     if (bookIndex === -1) {
    //         setRefetchBook(!refetchBook)
    //     }
    // }

    const onSelectOption = (e, id) => {
        onChangeBookShelf({ id: id }, e?.target?.value);

        // Change shelf of current book in bookList
        // const timeout = setTimeout(updateBookList(e, id), 500);
        // const timeout = setTimeout(alert('hello'), 500);
    };

    return (
        <AppContext.Provider
            value={{ onChangeBookShelf, onSelectOption, bookStateAppContext, setBookStateAppContext }}>
            {children}
        </AppContext.Provider>
    );
};

export default AppProvider;
