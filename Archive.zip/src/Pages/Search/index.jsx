import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./index.css";
import Book from "../../Components/Book";
import { search } from "../../BooksAPI";

function Search() {
  const navigate = useNavigate();
  const [bookList, setBookList] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const fetchSearchData = async (query, maxResults) => {
      const response = await search(query, maxResults);
      setBookList(response);
    };
    fetchSearchData(searchQuery, "10");
  }, [searchQuery]);

  console.log('bookList',bookList)

  return (
    <div className="search-books">
      <div className="search-books-bar">
        <a className="close-search" onClick={() => navigate("/home")}>
          Close
        </a>
        <div className="search-books-input-wrapper">
          <input
            type="text"
            placeholder="Search by title, author, or ISBN"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      <div className="search-books-results">
        <ol className="books-grid">
          <Book bookList={bookList}/>
        </ol>
      </div>
    </div>
  );
}

export default Search;
