import { useContext } from "react";
import { update } from "../../BooksAPI";
import { AppContext } from "../../ContextApi/AppContext";

function Book({ bookList, changeShelfFn }) {
  //   const onChangeBookShelf = async (bookID, shelf) => {
  //     const response = await update(bookID, shelf);
  //     console.log("response", response);
  //   };

  const { bookStateAppContext, setBookStateAppContext } = useContext(AppContext);

  const handleSetBookStateAppContext = (e, id) => {
    const newArr = [...bookStateAppContext];

    const bookIndex = newArr.findIndex((book) => book?.id === id);
    console.log("bookIndex",bookIndex)

    if (bookIndex !== -1) {
      newArr[bookIndex].shelf = e?.target?.value;
      setBookStateAppContext(newArr);
    }

    console.log('bookStateAppContext', bookStateAppContext)
  }

  const onSelectOption = async (e, id) => {
    const response = await update({ id: id }, e?.target?.value);
    // console.log('e?.target?.value: ', e?.target?.value)
    console.log("response", response);
    // console.log('changeShelfFn', !changeShelfFn)
    if (changeShelfFn !== undefined) {
      changeShelfFn(e, id);
    }

    handleSetBookStateAppContext(e, id);
  };


  return (
    <>
      {bookList?.length > 0 ? (
        bookList?.map((ele, index) => {
          return (
            <div key={index}>
              <li>
                <div className="book" key={index}>
                  <div className="book-top">
                    <div
                      className="book-cover"
                      style={{
                        width: 128,
                        height: 193,
                        backgroundImage: `url(${ele?.imageLinks?.smallThumbnail})`,
                      }}
                    ></div>
                    <div className="book-shelf-changer">
                      <select defaultValue={ele?.shelf || "none"} onChange={(e) => onSelectOption(e, ele.id)}>
                        <option value="moveTo" disabled>
                          Move to...
                        </option>
                        <option value="currentlyReading">
                          Currently Reading
                        </option>
                        <option value="wantToRead">Want to Read</option>
                        <option value="read">Read</option>
                        <option value="none">None</option>
                      </select>
                    </div>
                  </div>
                  <div className="book-title">{ele?.title}</div>
                  <div className="book-authors">{ele?.authors}</div>
                </div>
              </li>
            </div>
          );
        })
      ) : (
        <div></div>
      )}
    </>
  );
}

export default Book;
